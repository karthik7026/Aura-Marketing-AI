import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Header
from pymongo.database import Database

from backend.database import get_db
from backend.auth import decode_access_token

router = APIRouter(prefix="/api", tags=["Analytics & Notifications"])

def get_current_user_helper(authorization: str = Header(None), db: Database = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        return {"email": "demo.user@aura.com", "tokens": 9999}
    token = authorization.split(" ")[1]
    payload = decode_access_token(token)
    if not payload:
        return {"email": "demo.user@aura.com", "tokens": 9999}
    email = payload.get("sub", "demo.user@aura.com")
    user = db.users.find_one({"email": email})
    if not user:
        user = {"email": email, "tokens": 9999}
    return user

@router.get("/analytics/dashboard")
def get_analytics_dashboard(
    current_user: dict = Depends(get_current_user_helper),
    db: Database = Depends(get_db)
):
    user = db.users.find_one({"email": current_user["email"]})
    transactions = user.get("transactions", []) if user else []

    total_spent = sum(abs(tx.get("amount", 0)) for tx in transactions if tx.get("amount", 0) < 0)

    daily_usage = [
        {"day": "Mon", "tokens": 25},
        {"day": "Tue", "tokens": 40},
        {"day": "Wed", "tokens": 65},
        {"day": "Thu", "tokens": 30},
        {"day": "Fri", "tokens": 85},
        {"day": "Sat", "tokens": 45},
        {"day": "Sun", "tokens": 60}
    ]

    return {
        "status": "success",
        "email": current_user["email"],
        "tokens_balance": user.get("tokens", 9999) if user else 9999,
        "total_tokens_spent": total_spent,
        "daily_token_usage": daily_usage,
        "recent_activity": transactions[-5:] if transactions else []
    }

@router.get("/notifications")
def get_user_notifications(
    current_user: dict = Depends(get_current_user_helper)
):
    notifications = [
        {
            "id": "notif_1",
            "title": "Top 10 Opportunity Discovered",
            "message": "'best AI marketing platform' moved to rank #14 (+3,388 est. visitors/mo).",
            "timestamp": "10 mins ago",
            "read": False
        },
        {
            "id": "notif_2",
            "title": "AI Video Generated Successfully",
            "message": "30-second HD promo video compiled and exported to downloads.",
            "timestamp": "1 hour ago",
            "read": False
        },
        {
            "id": "notif_3",
            "title": "Indexing Directive Fixed",
            "message": "Robots.txt canonical error resolved on /features landing page.",
            "timestamp": "Yesterday",
            "read": True
        }
    ]
    unread_count = sum(1 for n in notifications if not n["read"])
    return {
        "status": "success",
        "unread_count": unread_count,
        "notifications": notifications
    }

@router.post("/notifications/mark-read")
def mark_notifications_read(
    current_user: dict = Depends(get_current_user_helper)
):
    return {
        "status": "success",
        "message": "All notifications marked as read"
    }
