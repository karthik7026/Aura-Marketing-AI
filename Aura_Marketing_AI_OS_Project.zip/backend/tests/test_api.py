import unittest
from fastapi.testclient import TestClient
from backend.main import app

class TestAuraMarketingAPI(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_root_status(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "online")

    def test_auth_and_user_flow(self):
        # Register test user
        email = "test.marketer@aura.com"
        reg_payload = {
            "email": email,
            "password": "securepassword123",
            "workspace_type": "marketing"
        }
        res_reg = self.client.post("/api/auth/register", json=reg_payload)
        # 200 OK or 400 if user exists
        self.assertIn(res_reg.status_code, [200, 400])

        # Login test user
        login_payload = {
            "email": email,
            "password": "securepassword123"
        }
        res_login = self.client.post("/api/auth/login", json=login_payload)
        self.assertEqual(res_login.status_code, 200)
        token = res_login.json()["access_token"]
        self.assertTrue(len(token) > 10)

    def test_payment_signature_verification(self):
        payment_payload = {
            "razorpay_order_id": "order_mock_test123",
            "razorpay_payment_id": "pay_mock_test123",
            "razorpay_signature": "mock_sig",
            "tier_name": "500 Tokens Package",
            "tokens_to_add": 500,
            "amount": 49.0
        }
        res_pay = self.client.post("/api/wallet/verify-payment", json=payment_payload)
        self.assertEqual(res_pay.status_code, 200)
        self.assertEqual(res_pay.json()["status"], "success")

    def test_marketing_doctor_beautifulsoup_diagnose(self):
        diag_payload = {
            "website_url": "https://github.com"
        }
        res_diag = self.client.post("/api/marketing-doctor/diagnose", json=diag_payload)
        self.assertEqual(res_diag.status_code, 200)
        data = res_diag.json()
        self.assertEqual(data["status"], "success")
        self.assertIn("live_metrics", data["diagnosis"])
        self.assertIn("scores", data["diagnosis"])

    def test_touchpoint_event_and_attribution(self):
        # 1. Track event
        event_payload = {
            "campaign_id": "CAMP_UNITTEST",
            "user_identifier": "usr_test_99",
            "channel": "google_ads",
            "event_type": "lead_conversion",
            "conversion_value": 250.0
        }
        res_ev = self.client.post("/api/campaigns/track-event", json=event_payload)
        self.assertEqual(res_ev.status_code, 200)
        self.assertEqual(res_ev.json()["status"], "success")

        # 2. Dynamic Attribution calculation
        res_attr = self.client.get("/api/campaigns/attribution/CAMP_UNITTEST")
        self.assertEqual(res_attr.status_code, 200)
        attr_data = res_attr.json()
        self.assertEqual(attr_data["status"], "success")
        self.assertIn("attribution_models", attr_data)
        self.assertIn("first_touch", attr_data["attribution_models"])
        self.assertIn("w_shaped", attr_data["attribution_models"])

if __name__ == "__main__":
    unittest.main()
