import os
import datetime
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Local imports
from backend.database import get_db, init_db_indexes
from backend.auth import get_password_hash

# Domain Routers
from backend.auth_router import router as auth_router
from backend.wallet_router import router as wallet_router
from backend.image_router import router as image_router
from backend.webaudit_router import router as webaudit_router
from backend.analytics_router import router as analytics_router
from backend.marketing_doctor import router as marketing_doctor_router
from backend.seo_engine import router as seo_engine_router
from backend.campaigns import router as campaigns_router

app = FastAPI(
    title="Aura Marketing AI Operating System API",
    description="Thin orchestrator backend mounting Auth, Wallet, AI Image, Web Audit, Analytics, Marketing Doctor, SEO Engine, and Campaigns routers.",
    version="2.1.0"
)

# Enable CORS for Next.js frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Domain Routers
app.include_router(auth_router)
app.include_router(wallet_router)
app.include_router(image_router)
app.include_router(webaudit_router)
app.include_router(analytics_router)
app.include_router(marketing_doctor_router)
app.include_router(seo_engine_router)
app.include_router(campaigns_router)

@app.on_event("startup")
def startup_event():
    db = next(get_db())
    init_db_indexes(db)
    
    # Seed default admin account if absent
    admin_email = "admin@aura.com"
    existing = db.users.find_one({"email": admin_email})
    if not existing:
        hashed = get_password_hash("admin123")
        admin_user = {
            "email": admin_email,
            "hashed_password": hashed,
            "provider": "local",
            "provider_id": None,
            "created_at": datetime.datetime.utcnow().isoformat() + "Z",
            "is_active": True,
            "tokens": 9999,
            "transactions": []
        }
        db.users.insert_one(admin_user)
        print("SUCCESS: Default admin account seeded (admin@aura.com / admin123).")

@app.get("/")
def root_status():
    return {
        "status": "online",
        "system": "Aura Marketing AI Operating System API",
        "version": "2.1.0",
        "documentation": "/docs"
    }
