import datetime
import uuid
from fastapi import APIRouter, Depends, HTTPException, status, Header
from pydantic import BaseModel, EmailStr
from typing import Optional
from pymongo.database import Database

from backend.database import get_db
from backend.auth import (
    get_password_hash, verify_password, 
    create_access_token, decode_access_token
)

router = APIRouter(prefix="/api/auth", tags=["Authentication & Identity"])

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    workspace_type: str = "video"
    company_name: Optional[str] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class OAuthRequest(BaseModel):
    credential: str
    email: str = ""
    provider_id: str = ""

@router.post("/register")
def register(req: RegisterRequest, db: Database = Depends(get_db)):
    email = req.email.lower().strip()
    existing = db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="User with this email already exists")

    hashed = get_password_hash(req.password)
    user_doc = {
        "email": email,
        "hashed_password": hashed,
        "provider": "local",
        "provider_id": None,
        "workspace_type": req.workspace_type,
        "company_name": req.company_name or "Aura Business",
        "created_at": datetime.datetime.utcnow().isoformat() + "Z",
        "is_active": True,
        "tokens": 9999,
        "transactions": []
    }

    db.users.insert_one(user_doc)
    access_token = create_access_token(data={"sub": email})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "email": email,
        "workspace_type": req.workspace_type
    }

@router.post("/login")
def login(req: LoginRequest, db: Database = Depends(get_db)):
    email = req.email.lower().strip()
    user = db.users.find_one({"email": email})
    if not user:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    if not verify_password(req.password, user.get("hashed_password", "")):
        raise HTTPException(status_code=400, detail="Invalid email or password")

    access_token = create_access_token(data={"sub": email})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "email": email,
        "workspace_type": user.get("workspace_type", "video")
    }

@router.get("/me")
def get_me(authorization: str = Header(None), db: Database = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid token")
    token = authorization.split(" ")[1]
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")

    email = payload.get("sub")
    user = db.users.find_one({"email": email})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return {
        "email": user["email"],
        "tokens": user.get("tokens", 9999),
        "workspace_type": user.get("workspace_type", "video"),
        "company_name": user.get("company_name", "Aura Business")
    }
